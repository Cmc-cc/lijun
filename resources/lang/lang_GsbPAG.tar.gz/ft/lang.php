<?php

return [
'png'=>'/new0404/images/i_flag_tw.png',
'yuyan'=>'语言',

'yebz'=>'帳戶餘額不足',
    'jibenchezi'=>'基本資料',
'zzwh'=>'正在維護',
'shangyige'=>'上一則',
'xiayige'=>'下一則',
'xtwhz'=>'系統維護中',
'qtxje'=>'請填寫金額',
'nqdsjsyyx'=>'你確定要將所有遊戲廳的錢轉回至中心錢包',
'nqdyc'=>'你確定要從',
'zhi'=>'至',
'sbcw'=>'失敗！錯誤',
  'xqgg'=>'先去逛逛',
'lxkf'=>'請聯系客服解决',
    'bdyhk'=>'绑定銀行卡',
       'czleixing'=>'充值類型',
    'zsxm'=>'真實姓名',
    'yhmc'=>'銀行名稱',
    'yhkh'=>'銀行卡號',
    'bdzsk'=>'绑定轉數快',
    'yhkgl'=>'銀行卡管理',
    'zskzh'=>'轉數快賬號',    
    'xzzsk'=>'新增轉數快',
     'yhklb'=>'銀行卡列表',
    'qsrckrxm'=>'請輸入持卡人姓名',   
    'qsrzskhm'=>'請輸入轉數快號碼',   
    'qsrusdtzh'=>'請輸入USDT賬號',  
    'qsryhkh'=>'請輸入您的銀行卡號',  
    'xgzfmm'=>'修改取款密碼',
    'wmztj'=>'未滿足條件',
    'liushui'=>'流水',
    'yjlq'=>'一鍵領取',
    'khje'=>'可換金額',
    'fsts'=>'因接口方遊戲數據返回時間不固定,所以實時反水金額不準確,建議您停止遊戲後一小時再領取實時反水！',
    'qsr'=>'請輸入',
    
    'lang'=>'繁体',

'lang_logo'=>'/data/ft.png',
'cksj'=>'存款時間',
'zanghao'=>'賬號',
'zdhq'=>'自動獲取',
'zhlx'=>'賬戶類型',
'mima'=>'密碼',
    'yhzh'=>'用戶賬號',
'denglu'=>'登入',

'qingshuru'=>'請輸入',

'qingzaicishuru'=>'請再次輸入',

'qkmm'=>'取款密碼',
'wjmm'=>'忘記密碼',
   'tkzx'=>'提款中心',
'ljzc'=>'立即註冊',
     'zhucezhanghu'=>'註冊賬戶',
'qingshuruzanghao'=>'賬號(6-9位字母與數字)',

'qingshurumima'=>'密碼由6-12位數字或字母組成',

'qingshuqukuanmima'=>'請輸入取款密碼6-10位',

'zhbjy'=>'該賬號被禁用',

'yhmhmmcw'=>'用戶名或密碼錯誤',

'qsryqm'=>'請輸入介紹人',

'lxkf'=>'聯系客服',

'xzapp'=>'已有賬號,下載APP',

'weixin'=>'微信',

'zxkf'=>'線上客服',
'kefu'=>'客服',

'zxrs'=>'線上人數',

'hyn'=>'歡迎您',

'zhuce'=>'註冊',

'chongzhi'=>'充值',
'jqjyjl'=>'近期交易記錄',
'edu'=>'額度',

'tikuan'=>'提款',

'dianzi'=>'電子',
'guanbi'=>'關閉',
'qxdr'=>'請先登入',
 'kqyx'=>'開啟遊戲',
'gjdh'=>'國際電話',
'shixun'=>'視訊',

'caipiao'=>'彩票',

'tiyu'=>'體育',

'dianjing'=>'電競',

'qipai'=>'棋牌',

'buyu'=>'捕魚',

'shouye'=>'首頁',

'yhhd'=>'優惠活動',
'jindu'=>'進度',
'youhui'=>'優惠',

'edzh'=>'資金回收',

'tzjl'=>'投注記錄',

'wode'=>'我的',

'hdzx'=>'活動中心',

'hdxq'=>'活動詳情',

'yehz'=>'餘額劃轉',

'zhye'=>'帳戶餘額',

'qxzpt'=>'請選擇平臺',

'zhuanru'=>'轉入',

'zhuanchu'=>'轉出',

'tijiao'=>'提交',

'yxlb'=>'遊戲清單',

'wkt'=>'未開通',

'yjzr'=>'一鍵轉入',

'yjzc'=>'一鍵轉出',

'sxcg'=>'重繪成功',

'srje'=>'请輸入金額',

'yxjl'=>'遊戲記錄',

'yxxz'=>'有效下注',

'yuan'=>'元',

'wanfa'=>'玩法',

'touzhu'=>'投注',

'zjj'=>'中獎金',

'zzhye'=>'主帳戶餘額',

'jrtz'=>'今日投注',

'jryk'=>'今日盈虧',

'zhuan'=>'轉',

'ssfs'=>'實時返水',

'fsjl'=>'返水記錄',

'czjl'=>'充值記錄',

'txjl'=>'提現記錄',

'edzhjl'=>'額度轉換記錄',

'dlzx'=>'代理中心',

'xxzx'=>'消息中心',

'xgmm'=>'修改密碼',

'tcdl'=>'退出登入',


'qxzczfs'=>'選擇充值管道',
    'yhzz'=>'銀行轉賬',
'bldzz'=>'便利商店增值',

'hdsj'=>'活動時間：長期有效',
'hdqj'=>'活動期間',
'sqhd'=>'申請活動',

'msrkh'=>'免輸入卡號方便快捷',

'zfbsm'=>'支付寶掃碼充值',

'zsk'=>'轉數快',

'czje'=>'充值金額',

'skewm'=>'收款二維碼',

'fkjt'=>'付款截圖',

'zftx'=>'支付時必須足元足角支付（最低支付金額100元）',

'qrcz'=>'確認充值',
'czje'=>'存款金額',
'yy'=>'原因',
'zdyz'=>'最多只能選擇1張圖片',

'xingming'=>'姓名',
'khxm'=>'開戶姓名',
'yhzh2'=>'銀行賬號',
'qsrfkrxm'=>'請輸入付款人姓名',

'zfbts1'=>'1、在金額轉出之後請務必填寫該頁下方的匯款資訊表格,以便財務系統能够及時的為您確認並添加金額到您的會員帳戶中。',

'zfbts2'=>'2、本公司最低存款金額為100元,公司財務系統將對銀行存款的會員按實際存款金額實行返利派送。',

'zfbts3'=>'3、跨行轉帳請您使用跨行快匯。',

'skzh'=>'收款帳戶',

'skzhm'=>'收款帳戶名',

'fuzhi'=>'複製',

'fzcg'=>'複製成功',

'tixian'=>'提現',

'txfs'=>'提現管道',

'qxz'=>'請選擇',

'mlye'=>'碼量餘額',

'skzh'=>'收款賬號',

'tkje'=>'提款金額',

'tk100'=>'提款金額至少100元',

'tkmm'=>'提款密碼',

'tkts'=>'如提現出現打碼量不足,而您的流水已經超過了充值金額的八倍,請您稍後再來提現,因為遊戲方下注數據沒有返還到本現金站,造成您的流水不能及時更新,造成的不便請您諒解,或者聯系線上客服！',

'dqr'=>'待確認',

'hkcg'=>'匯款成功',
'qikuangmm'=>'輸入新密碼4位數取款密碼',
'qrxmm'=>'確認新密碼（4位數取款密碼）',
'qrztxxx'=>'請認真填寫信息',
'xgcg'=>'修改成功',
'qrxmm620'=>'確認新密碼（6-20個常規字符）',
'srxmm620'=>'輸入新密碼（6-20個常規字符）',
'srjmm'=>'輸入舊密碼',
'hksb'=>'匯款失敗',

'xtgg'=>'系統公告',

'khdz'=>'開戶地址',

'xgdlmm'=>'修改登入密碼',

'jmm'=>'舊密碼',

'xmm'=>'新密碼',

'qrmm'=>'確認密碼',

'qr'=>'確認',

'zfmm'=>'支付密碼',

'dlmm'=>'登入密碼',

'x6wcsz'=>'須6比特純數位',

'tglj'=>'推廣連結',

'fzlj'=>'複製連結',

'ewmtg'=>'二維碼推廣',

'yjffjl'=>'傭金發放',

'xxhyckjl'=>'會員存款',

'xxhytkjl'=>'會員提款',

'xxhy'=>'會員',

'hysybb'=>'會員輸贏',

'kssj'=>'開始時間',

'jssj'=>'結束時間',

'yhm'=>'用戶名',
'ckjl'=>'存款記錄',
'hljl'=>'紅利記錄',
'tkjl'=>'提款記錄',
'xgqkmm'=>'修改取款密碼',
'chaxun'=>'査詢',

'ckzs'=>'存款總額',

'ckbs'=>'存款筆數',

'tkze'=>'提款總額',

'tkbs'=>'提款筆數',

'hlze'=>'紅利總額',

'hlbs'=>'紅利筆數',

'yl'=>'盈利',

'hysy'=>'會員輸贏',
 'qddpz'=>'您尚有存款未批准，請等待批准',
'ckts'=>'您有一筆存款暫未通過,無法重複提交存款',

'jebxdy'=>'金額必須大於等於',
'jebxxy'=>'金額必須小於等於',
'qsrzqdsz'=>'請輸入正確的數位,小數保留兩位小數',

'qscjt'=>'請上傳付款成功截圖',

'mtzdtk'=>'每天最多只能申請提款',

'ci'=>'次',

'dmlbz'=>'您的打碼量不足,無法提現',

'tkjedyye'=>'提款金額大於餘額',

'qkmmbzq'=>'取款密碼不正確',

'tjcg'=>'提交成功',

"zggsyh"=>"中國工商銀行",

"zgjsyh"=>"中國建設銀行",

"zgnyyh"=>"中國農業銀行",

"zgyh"=>"中國銀行",

"zgjtyh"=>"中國交通銀行",

"zsyh"=>"招商銀行",

"gfyh"=>"廣發銀行",

"payh"=>"平安銀行",

"pfyh"=>"浦發銀行",

"msyh"=>"民生銀行",

"zgyz"=>"中國郵政儲蓄銀行",

"hxyh"=>"華夏銀行",

"szfz"=>"深圳發展銀行",

"zxyh"=>"中信銀行",

"xyyh"=>"興業銀行",

"gdyh"=>"光大銀行",

"zdyh"=>"渣打銀行",

"hfyh"=>"滙豐銀行",

"zxyh"=>"中興銀行",

"hsyh"=>"恒生銀行",

"cxyh"=>"創新銀行",

"ymmcw"=>"原密碼錯誤",
"zcdl"=>'代理註冊',
'daili'=>'代理',
'user'=>'會員',
'ymmcw'=>'原密碼錯誤',

'zcdl'=>'代理註冊',

'daili'=>'代理',

'user'=>'會員',

'yzm'=>'驗證碼',
'chakan'=>'查看',
'hqyzm'=>'獲取驗證碼',

'cxfs'=>'重新發送',

'fscg'=>'發送成功',

'qxbdsj'=>'請先綁定手機',

'bdsj'=>'綁定手機',

'sjh'=>'手機號',

'ybdsjh'=>'已綁定手機號',

'yzmcw'=>'驗證碼錯誤',

'yzmygq'=>'驗證碼已過期',

'yswrjqd'=>'英屬維京群島',

'bvirz'=>'（bvi）認證',

'jtgfyy'=>'集團官方運營',

'flb'=>'菲律賓（pagcor）',

'jgbczz'=>'監管博彩執照',
'xclx'=>'查詢類型',
'hdzx'=>'活動中心',
'dingdanchaxun'=>'訂單查詢',
'kfzx'=>'客服中心',

'edzh'=>'資金回收',

'grzx'=>'個人中心',

'ckwt'=>'存款問題',

'qkwt'=>'取款問題',

'zhwt'=>'帳戶問題',

'yhhd'=>'優惠活動',

'dljm'=>'代理加盟',

'yxcg'=>'遊戲場館',

'sxje'=>'重繪金額',

'zjhs'=>'資金回收',
'zjls'=>'資金流水',
'zxqb'=>'中心錢包',

'yxqb'=>'遊戲錢包',

'qsrzzje'=>'請輸入轉帳金額',

'ljzz'=>'立即轉帳',

'xzyx'=>'選擇遊戲',

'quxiao'=>'取消',

'jzz'=>'加載中',

'hsz'=>'回收中',

'lqmrfl'=>'領取每日福利',

'byxzze'=>'本月下注總額',

'fanshui'=>'紅利',

'qbxx'=>'全部消息',
'quanbu'=>'全部',
'xiaoxi'=>'消息',

'zwjl'=>'暫無記錄',
 'quedingtc'=>'確實要退出嗎?',
'gengduo'=>'更多',

'flhd'=>'福利活動',

'xiangxi'=>'詳細',
'qxzckyh'=>'請選擇存款銀行',

'baobiao'=>'報表',

'cunkuan'=>'存款',
'ckyh'=>'存款銀行',
  'hkyh'=>'匯款銀行',
'dqr'=>'待確認',
'hkxm'=>'匯款姓名',
'chenggong'=>'成功',

'shibai'=>'失敗',

'zzxm'=>'自主洗碼,實时結算,請投注達標後再試',

'xnbzf'=>'虛擬幣支付',

'xfjzf'=>'消費卷支付',

'skyh'=>'收款銀行',

'hkje'=>'匯款金額',

'qjl'=>'請記錄以下收款資訊,並匯款',

'fhcxsr'=>'返回重新輸入',

'cz1'=>'注：為了可以快速上分,請按照系統提示金額進行轉帳,',

'cz2'=>'轉帳金額精確到小數點後兩位,如不是按照提示金額轉帳系統會自動拒絕該轉帳請求',

'cz3'=>'並且不做進行補分操作！ 謝謝',

'hqskyhxx'=>'獲取收款銀行資訊',
'hqskyhxxx'=>'獲取收款銀行信息',

'cz4'=>'確認已經轉帳到指定帳戶,申請上分？',

'czdz'=>'充值地址',

'syml'=>'剩餘碼量',

'zhuti'=>'主題',
'fanhui'=>'返回',
'neirong'=>'內容',

'fssj'=>'發送時間',

'xzrq'=>'選擇日期',

'jinri'=>'今日',

'day'=>'天',

'zcgcz'=>'總成功充值',

'jine'=>'金額',

'shijian'=>'時間',

'zhuangtai'=>'狀態',
'hqskzfm'=>'獲取收款支付碼',
'bzzx'=>'幫助中心',
'xxq'=>'休閒區',
'zhuce_shouji'=> '手機號為8-11個數字!',
'zhuce_huoquyanzhema' => '獲取驗證碼',
'zhuce_yiyouzhanghao' => '已有賬號',
'xgdenglumima' => '修改登錄密碼',
'denglumima' => '登錄密碼',
'querenmima' => '確認登錄密碼',
'liangcimimabuyizhi' => '兩次密碼輸入不一致',
'cuowu' => '錯誤',
'sqjd'=>'申請進度',
'hgbt'=>'活動標題',
'ndhdsqwtg'=>'你的活動申請未通過，原因',
'gongxini'=>'恭喜你，你的活動申請已審核通過，贈送金額已發放到你的賬戶，請查收！ ',
'ndhdsqzzsh'=>'你的活動申請正在審核，請耐心等耐！ ',
'zwcjhd'=>'暫無參加活動',
'yidu'=>'已讀',
'huo' => '或',
'jieshaoren' => '介紹人',
'p-6-12' => '請輸入6-12個字符或數字的',
'denglumimaqueren' => '登錄密碼確認',
'xuyuyuanmimaxiangtong' => '需與原密碼相同',
'zhenshixingming' => '真實姓名',
'zhengquezhenshixingming' => '請輸入真實英文姓名',
'qingtianxiezhengquedeshoujihao' => '請填寫真實手機號碼，密碼找回途徑之一',
'tongyizunxuan' => '同意並願意遵守',
'yonghuxieyi' => '用戶協議',
'he' => '和',
'yinsitiaokuan' => '隱私條款',
'lijizhuce' => '立即註冊',
'weitongyiyonghuxieyi' => '未同意用户协议及条款!',
'likedengru' => '立即登入',
'mianfeizhuce' => '免費註冊',
'zijinhuishou' => '資金回收',
'yinhangka' => '銀行卡',
    'alipay'=>'支付寶掃碼',
'shengyumaliang' => '剩餘碼量',
'yue' => '余額',
'querentixian' => '確認提现',
'zhuanhuankuai' => '轉數快',
'bianlidianzengzhi' => '便利商店增值',
'yinhanghuikuan'=>'銀行匯款',
'xunibizhifu' => '虛擬幣支付',
'qingshurujine' => '請輸入金額',
'huikuanjine' => '匯款金額',
'chongzhi_wenan1' => '請記錄以下收款信息，並匯款',
'chongzhi_wenan2' => '注：爲了可以快速上分，請按照系統提示金額進行轉賬，轉賬金額精確到小數點后兩位，如不是按照提示金額轉賬系統會自動拒絕該轉賬請求并且不做進行補分操作！謝謝',
'fuzhichenggong' => '復製成功',
'fuzhishibai' => '復製失敗',
'denglu' => '登錄',
'zhuce' => '註冊',
'shoujixiazai' => '手機下載',
'yinhangkabangding' => '銀行卡綁定',
'shanglajiazaigengduo' => '上拉加載更多',
'queshaocanshu' => '缺失必要的參數',
'meiyougengduole' => '沒有更多了',
'jiaoyijine' => '交易金額',
'dingdanhao' => '訂單號',
'jiaoyishijian' => '交易時間',
'jiaoyifangshi' => '交易方式',
'jiaoyizhuangtai' => '交易狀態',
'beizhu' => '備註',
'jiazaizhong' => '加載中',
'zongchenggongtixian' => '總成功提现',
'fanhui' => '返回',
'jine' => '金額',
'dongzuo' => '動作',
'youximingcheng' => '遊戲名稱',
'shuruzhanghu' => '轉入賬戶',
'shuchuzhanghu' => '轉出賬戶',
'tiyu'=>'體育',
'zhenren'=>'真人',
'qipai'=>'棋牌',
'caipiao'=>'彩票',
'dianzi'=>'電子',
'buyu'=>'捕魚',
'youxizhonglei'=>'遊戲種類',
'quedihng'=>'確定',
'sunyi' => '損益',
'yijianfanshuijiesuan' => '壹鍵返水結算',
'kejiesuanjine' => '可結算返水總金額',
'quanbuximajiesuan' => '全部返水結算',
'fanshui_alt' => '自主返水，實時結算，請投註達標後再試！',
'leixing' => '類型',
'zongtouzhu' => '總投註',
'zongfanshu' => '總返水',
'shuaxinjine' => '刷新金額',
'xiangxizhangkai' => '詳細展開',
'lijizhuanzhang' => '立即轉賬',
'qingshuruzhuanzhangjine' => '請輸入轉賬金額',
'bangding_title' => '【銀行卡或轉數快賬號，各只能綁定一組，同時必須為相同姓名】',
'dengchu' => '登出',
'sqdl'=>'申請代理',
'sqly'=>'申請理由',
'all'=>'全部',
'bkcfsq'=>'不可重複申請',
'qczhzl'=>'請充值後再來申請',

'xzyhk'=>'新增银行卡',
'tips1'=>'會員只能綁定一個銀行卡帳戶和一個轉數快帳戶，並且戶口持有人姓名必須為相同，綁定後如需修改，請與我們24小時在線客服聯絡。',
'qxcz'=>'請先充值',
'yjsql'=>'你已申請該活動，請明日充值後申請!',
'hdyjs'=>'活動已結束，請申請其他活動',
'grxx'=>'個人信息',
'genghuan'=>'更換',
'ykh'=>'銀行卡',
'yebz'=>'帳戶餘額不足',

'zzwh'=>'正在維護',

'sbcw'=>'失敗！錯誤',

'lxkf'=>'請聯系客服解决',
    
    'xgzfmm'=>'修改取款密碼',
    'wmztj'=>'未滿足條件',
    'liushui'=>'流水',
    'yjlq'=>'一鍵領取',
    'khje'=>'可換金額',
    'fsts'=>'因接口方遊戲數據返回時間不固定,所以實時反水金額不準確,建議您停止遊戲後一小時再領取實時反水！',
    'qsr'=>'請輸入',
    
    'lang'=>'繁体',

'lang_logo'=>'/data/ft.png',

'zanghao'=>'賬號',

'mima'=>'密碼',

'denglu'=>'登入',

'qingshuru'=>'請輸入',

'qingzaicishuru'=>'請再次輸入',

'qkmm'=>'取款密碼',

'wjmm'=>'忘記密碼',

'ljzc'=>'立即注册',

'qingshuruzanghao'=>'賬號(6-9位細寫字母與數字)',

'qingshurumima'=>'密碼由6-12位數字或字母組成',

'qingshuqukuanmima'=>'請輸入取款密碼6-10位',

'zhbjy'=>'該賬號被禁用',

'yhmhmmcw'=>'用戶名或密碼錯誤',

'qsryqm'=>'請輸入介紹人',

'lxkf'=>'聯系客服',

'xzapp'=>'已有賬號,下載APP',

'weixin'=>'微信',

'zxkf'=>'線上客服',

'zxrs'=>'線上人數',

'hyn'=>'歡迎您',

'zhuce'=>'注册',

'chongzhi'=>'充值',

'edu'=>'額度',

'tikuan'=>'提款',

'dianzi'=>'電子',

'shixun'=>'視訊',

'caipiao'=>'彩票',

'tiyu'=>'體育',

'dianjing'=>'電競',

'qipai'=>'棋牌',

'buyu'=>'捕魚',

'shouye'=>'首頁',

'yhhd'=>'優惠活動',

'edzh'=>'資金回收',

'tzjl'=>'投注記錄',

'wode'=>'我的',

'hdzx'=>'活動中心',

'hdxq'=>'活動詳情',

'yehz'=>'餘額劃轉',

'zhye'=>'帳戶餘額',

'qxzpt'=>'請選擇平臺',

'zhuanru'=>'轉入',

'zhuanchu'=>'轉出',

'tijiao'=>'提交',

'yxlb'=>'遊戲清單',

'wkt'=>'未開通',

'yjzr'=>'一鍵轉入',

'yjzc'=>'一鍵轉出',

'sxcg'=>'重繪成功',

'srje'=>'请輸入金額',

'yxjl'=>'遊戲記錄',

'yxxz'=>'有效下注',

'yuan'=>'元',

'wanfa'=>'玩法',

'touzhu'=>'投注',

'zjj'=>'中獎金',

'zzhye'=>'主帳戶餘額',

'jrtz'=>'今日投注',

'jryk'=>'今日盈虧',

'zhuan'=>'轉',

'ssfs'=>'實时返水',

'fsjl'=>'返水記錄',

'czjl'=>'充值記錄',

'txjl'=>'提現記錄',

'edzhjl'=>'額度轉換記錄',

'dlzx'=>'代理中心',

'xxzx'=>'消息中心',

'xgmm'=>'修改密碼',

'tcdl'=>'退出登入',


'qxzczfs'=>'選擇充值管道',

'bldzz'=>'便利商店增值',

'hdsj'=>'活動時間：長期有效',

'msrkh'=>'免輸入卡號方便快捷',

'zfbsm'=>'支付寶掃碼充值',

'zsk'=>'轉數快',

'czje'=>'充值金額',

'skewm'=>'收款二維碼',

'fkjt'=>'付款截圖',

'zftx'=>'支付時必須足元足角支付（最低支付金額100元）',

'qrcz'=>'確認充值',

'zdyz'=>'最多只能選擇1張圖片',

'xingming'=>'姓名',

'qsrfkrxm'=>'請輸入付款人姓名',

'zfbts1'=>'1、在金額轉出之後請務必填寫該頁下方的匯款資訊表格,以便財務系統能够及時的為您確認並添加金額到您的會員帳戶中。',

'zfbts2'=>'2、本公司最低存款金額為100元,公司財務系統將對銀行存款的會員按實際存款金額實行返利派送。',

'zfbts3'=>'3、跨行轉帳請您使用跨行快匯。',

'skzh'=>'收款帳戶',

'skzhm'=>'收款帳戶名',

'fuzhi'=>'複製',

'fzcg'=>'複製成功',

'tixian'=>'提現',

'txfs'=>'提現管道',

'qxz'=>'請選擇',

'mlye'=>'碼量餘額',

'skzh'=>'收款賬號',

'tkje'=>'提款金額',

'tk100'=>'提款金額至少100元',

'tkmm'=>'提款密碼',

'tkts'=>'如提現出現打碼量不足,而您的流水已經超過了充值金額的八倍,請您稍後再來提現,因為遊戲方下注數據沒有返還到本現金站,造成您的流水不能及時更新,造成的不便請您諒解,或者聯系線上客服！',

'dqr'=>'待確認',

'hkcg'=>'匯款成功',

'hksb'=>'匯款失敗',

'xtgg'=>'系統公告',

'khdz'=>'開戶地址',

'xgdlmm'=>'修改登入密碼',

'jmm'=>'舊密碼',

'xmm'=>'新密碼',

'qrmm'=>'確認密碼',

'qr'=>'確認',

'zfmm'=>'取款密碼',

'dlmm'=>'登入密碼',

'x6wcsz'=>'須6比特純數位',

'tglj'=>'推廣連結',

'fzlj'=>'複製連結',

'ewmtg'=>'二維碼推廣',

'yjffjl'=>'傭金發放',

'xxhyckjl'=>'會員存款',

'xxhytkjl'=>'會員提款',

'xxhy'=>'會員',

'hysybb'=>'會員輸贏',

'kssj'=>'開始時間',

'jssj'=>'結束時間',

'yhm'=>'用戶名',

'chaxun'=>'査詢',

'ckzs'=>'存款總額',

'ckbs'=>'存款筆數',

'tkze'=>'提款總額',

'tkbs'=>'提款筆數',

'hlze'=>'紅利總額',

'hlbs'=>'紅利筆數',

'yl'=>'盈利',

'hysy'=>'會員輸贏',

'ckts'=>'您有一筆存款暫未通過,無法重複提交存款',

'jebxdy'=>'金額必須大於等於',

'qsrzqdsz'=>'請輸入正確的數位,小數保留兩位小數',

'qscjt'=>'請上傳付款成功截圖',

'mtzdtk'=>'每天最多只能申請提款',

'ci'=>'次',

'dmlbz'=>'您的打碼量不足,無法提現',

'tkjedyye'=>'提款金額大於餘額',

'qkmmbzq'=>'取款密碼不正確',

'tjcg'=>'提交成功',

"zggsyh"=>"中國工商銀行",

"zgjsyh"=>"中國建設銀行",

"zgnyyh"=>"中國農業銀行",

"zgyh"=>"中國銀行",

"zgjtyh"=>"中國交通銀行",

"zsyh"=>"招商銀行",

"gfyh"=>"廣發銀行",

"payh"=>"平安銀行",

"pfyh"=>"浦發銀行",

"msyh"=>"民生銀行",

"zgyz"=>"中國郵政儲蓄銀行",

"hxyh"=>"華夏銀行",

"szfz"=>"深圳發展銀行",

"zxyh"=>"中信銀行",

"xyyh"=>"興業銀行",

"gdyh"=>"光大銀行",

"zdyh"=>"渣打銀行",

"hfyh"=>"滙豐銀行",

"zxyh"=>"中興銀行",

"hsyh"=>"恒生銀行",

"cxyh"=>"創新銀行",

"ymmcw"=>"原密碼錯誤",
"zcdl"=>'代理注册',
'daili'=>'代理',
'user'=>'會員',
'ymmcw'=>'原密碼錯誤',

'zcdl'=>'代理注册',

'daili'=>'代理',

'user'=>'會員',

'yzm'=>'驗證碼',

'hqyzm'=>'獲取驗證碼',

'cxfs'=>'重新發送',

'fscg'=>'發送成功',

'qxbdsj'=>'請先綁定手機',

'bdsj'=>'綁定手機',

'sjh'=>'手機號',

'ybdsjh'=>'已綁定手機號',

'yzmcw'=>'驗證碼錯誤',

'yzmygq'=>'驗證碼已過期',

'yswrjqd'=>'英屬維京群島',

'bvirz'=>'（bvi）認證',

'jtgfyy'=>'集團官方運營',

'flb'=>'菲律賓（pagcor）',

'jgbczz'=>'監管博彩執照',

'hdzx'=>'活動中心',

'kfzx'=>'客服中心',

'edzh'=>'資金回收',

'grzx'=>'個人中心',

'ckwt'=>'存款問題',

'qkwt'=>'取款問題',

'zhwt'=>'帳戶問題',

'yhhd'=>'優惠活動',

'dljm'=>'代理加盟',

'yxcg'=>'遊戲場館',

'sxje'=>'重繪金額',

'zjhs'=>'資金回收',

'zxqb'=>'中心錢包',

'yxqb'=>'遊戲錢包',

'qsrzzje'=>'請輸入轉帳金額',

'ljzz'=>'立即轉帳',

'xzyx'=>'選擇遊戲',

'quxiao'=>'取消',

'jzz'=>'加載中',

'hsz'=>'回收中',

'lqmrfl'=>'領取每日福利',

'byxzze'=>'本月下注總額',

'fanshui'=>'紅利',

'qbxx'=>'全部消息',

'xiaoxi'=>'消息',

'zwjl'=>'暫無記錄',

'gengduo'=>'更多',

'flhd'=>'福利活動',

'xiangxi'=>'詳細',

'baobiao'=>'報表',

'cunkuan'=>'存款',

'dqr'=>'待確認',

'chenggong'=>'成功',

'shibai'=>'失敗',

'zzxm'=>'自主洗碼,實时結算,請投注達標後再試',

'xnbzf'=>'虛擬幣支付',

'xfjzf'=>'消費卷支付',

'skyh'=>'收款銀行',

'hkje'=>'匯款金額',

'qjl'=>'請記錄以下收款資訊,並匯款',

'fhcxsr'=>'返回重新輸入',

'cz1'=>'注：為了可以快速上分,請按照系統提示金額進行轉帳,',

'cz2'=>'轉帳金額精確到小數點後兩位,如不是按照提示金額轉帳系統會自動拒絕該轉帳請求',

'cz3'=>'並且不做進行補分操作！ 謝謝',

'hqskyhxx'=>'獲取收款銀行資訊',

'cz4'=>'確認已經轉帳到指定帳戶,申請上分？',

'czdz'=>'充值地址',

'syml'=>'剩餘碼量',

'zhuti'=>'主題',

'neirong'=>'內容',

'fssj'=>'發送時間',

'xzrq'=>'選擇日期',

'jinri'=>'今日',

'day'=>'天',

'zcgcz'=>'總成功充值',

'jine'=>'金額',

'shijian'=>'時間',

'zhuangtai'=>'狀態',
'bzzx'=>'幫助中心',
'qxdryx'=>'請登入游戲',
'xxq'=>'休閒區',
'shengyujihe'=>'剩餘稽核',
'xiangxilianxikefu'=>'詳細請聯絡客服',
'touzhujilu'=>'投注記錄',
'zonghongli'=>'總紅利',
'hljl'=>'紅利記錄',
    'login_zhuce' => '註冊新用戶',
    'fanhuidenglu' => '返回登錄',
    'zhanghao' => '帳號'
];
    