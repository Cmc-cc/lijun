<?php

return [
    
    'yebz' =>'insufficient account balance',
'fanhui'=>'return',
'kqyx'=>'open game',
'zhuanhuankuai'=>'FPS',
'yinhangka'=>'Bank Card',
'xtwhz'=>'system maintenance',
'qtxje'=>'please fill in the amount',
'nqdsjsyyx'=>'you are sure to transfer all the money from the game hall to the central wallet',
'nqdyc'=>'you are sure to start from',
'zhi'=>'to',
'xclx'=>'query type',
 'yhzh2'=>'bank account',
 'ckjl'=>'deposit record',
'hljl'=>'bonus record',
'tkjl'=>'withdrawal record',
'xgqkmm'=>'modify withdrawal password',
'khxm'=>'account opening name',
 'hkyh'=>'remittance bank',
 'shangyige'=>'previous',
'xiayige'=>'next',
'cksj'=>'deposit time',
'huikuanjine' => 'remittance amount',
'hqskzfm'=>'get payment code',
'hqskyhxxx'=>'get beneficiary bank information',
'qxzckyh'=>'please select deposit bank',
'hkxm'=>'remittance name',
'xgdenglumima' => 'modify login password',
'jqjyjl'=>'recent transaction history',
'gjdh'=>'International call',
    'jibenchezi'=>'basic information',
'zzwh' =>'being maintained',
'zijinhuishou' => 'fund recovery',
'yinhangkabangding' => 'Bank Card',
'sbcw'=>' failed! Error',
'yinhanghuikuan'=>'bank transfer',
    'yzm'=>'verification code',
'chakan'=>'check',
'zdhq'=>'automatic acquisition',
    'alipay'=>'alipay scan code',
    'yhkgl'=>'bank card management',
 'xzzsk'=>'add FPS',
    'czleixing'=>'recharge type',
 'all'=>'all',
     'sjh'=>'phone number',
         'hqyzm'=>'get code',
 'shoujixiazai' => 'App',
         'yhklb'=>'list of bank cards',
    'bdyhk'=>'bind bank card',
    'zsxm'=>'real name',
    'yhmc'=>'bank name',
    'yhkh'=>'bank card numbe',
    'bdzsk'=>'binding fps',
    'zskzh'=>'FPS account number',            
    'qsrckrxm'=>'please enter the cardholder name',   
    'qsrzskhm'=>'Please enter the FPS number',   
    'qsrusdtzh'=>'please enter USDT account number',  
    'qsryhkh'=>'please enter your bank card number',  
    'xqgg'=>'go shopping first',
'lxkf' =>'please contact customer service for solution',
    'bdsj'=>'Phone',
   'xgzfmm'=>'payment password',
   'wmztj'=>'Conditions not met',
   'liushui'=>'Water',
   'yjlq'=>'Collection',
   'khje'=>'Exchangeable amount',
   'fsts'=>'Because the game data return time of the interface party is not fixed, the real-time backwater amount is inaccurate. It is recommended that you receive the real-time backwater one hour after stopping the game!',
   'qsr'=>'Please enter',
    
  'lang' =>'En',

'lang_logo'=>'/data/en_us.png',

'zanghao' =>'account number',

'mima'=>' password',

'denglu'=>' Login',

'qingshuru' =>'please enter',

'qingzaicishuru' =>'please enter again',

'qkmm' =>'withdrawal password',

'wjmm' =>'forgot password',

'ljzc' =>'register now',

'zhbjy' =>'the account is disabled',

'yhmmcw' =>'wrong user name or password',

'qsryqm' =>'please enter the introducer',

'lxkf' =>'contact customer service',

'xzapp' =>'existing account, Download app',

'weixin' =>'wechat',

'zxkf' =>'online customer service',
'kefu' =>'Contact',

'zxrs' =>' Now online',

'hyn' =>'welcome',

'zhuce' =>'Register',

'chongzhi' =>'Recharge',

'edu' =>'quota',

'tikuan'=>' withdrawal',

'dianzi'=>' electronic',

'shixun'=>' video',

'caipiao' =>'lottery',

'tiyu'=>' Sports',

'dianjing'=>' ESports',

'qipai' =>'chess',

'buyu' =>'fishing',

'shouye'=>' Home',

'yhhd' =>'preferential activities',
'jindu'=>'schedule',
'guanbi'=>'closure',
'qxdr'=>'please login first',
'kqyx'=>'open game',

'youhui' =>'Promotion',

'edzh' =>'quota conversion',

'tzjl'=>' betting record',

'wode' =>'mine',

'hdzx' =>'activity center',

'hdxq' =>'activity details',

'yehz' =>'balance transfer',

'zhye' =>'account balance',

'qxzpt' =>'please select a platform',

'zhuanru' =>'transfer in',

'zhuanchu' =>'transfer out',

'tijiao'=>' submit',

'yxlb' =>'game list',
   'tkzx'=>'withdrawal center',
'wkt' =>'not opened',

'yjzr' =>'all in',
    'yhzh'=>'user account',
'yjzc' =>'all out',

'sxcg'=>' refresh succeeded',
  'yhmhmmcw'=>'wrong user name or password',
'srje'=>' enter amount',
'denglumima' => 'login password',
'chongzhi_wenan1' => 'Please record the following payment information and remit money',
'chongzhi_wenan2' => 'Note: In order to quickly increase the score, please transfer the amount according to the system prompt. The transfer amount is accurate to two decimal places. If you do not follow the prompt amount, the transfer system will automatically reject the transfer request and do not make up. Sub-operation! thanks',
'yxjl' =>'game record',

'yxxz' =>'valid bet',

'yuan' =>'$',

'wanfa' =>'play method',

'touzhu'=>' betting',

'zjj' =>'prize money',

'zzhye' =>'master account balance',

'jrtz' =>'bet today',

'jryk' =>'profit and loss today',

'zhuan' =>'transfer',

'ssfs' =>'real time water return',

'fsjl' =>'water return record',

'czjl' =>'recharge record',

'txjl'=>' withdrawal record',

'edzhjl' =>'quota conversion record',

'dlzx'=>'Agent',

'xxzx' =>'message center',

'xgmm' =>'modify password',

'tcdl'=>' exit Login',


'qxzczfs' =>' select recharge method',

'bldzz' =>'Convenience Store',
    'yhzz'=>'bank transfer',
'hdsj' =>'activity time: long term effective',
'hdqj'=>'during the activity',
'sqhd'=>'application activity',

'msrkh'=>' no need to input card number, convenient and fast',

'zfbsm'=>'Alipay scan code recharge',

'zsk' =>'FPS',

'czje' =>'recharge amount',

'skewm'=>'QR code',

'fkjt' =>'payment screenshot',

'zftx' =>'the payment must be paid in full Yuan and jiao (the minimum payment amount is 100 yuan)',

'qrcz' =>'confirm recharge',

'zdyz' =>'only 1 picture can be selected at most',

'Xingming' =>'name',

'qsrfkrxm' => "please enter the payer's name",

'zfbts1' =>'1. Please fill in the remittance information form at the bottom of this page after the amount is transferred out, so that the financial system can confirm and add the amount to your member account in time.',

'zfbts2' =>'2. The minimum deposit amount of the company is 100 yuan, and the financial system of the company will distribute rebates to members with bank deposits according to the actual deposit amount.',

'zfbts3' =>'3. For inter-bank transfer, please use inter-bank express remittance.',

'skzh'=>' collection account',

'skzhm'=>' Bank Name',

'fuzhi' =>'copy',

'fzcg' =>'copy succeeded',

'tixian'=>' Withdrawal',

'txfs' =>'withdrawal method',

'qxz' =>'please select',

'mlye'=>' code quantity balance',

'skzh'=>' Bank Account',

'tkje'=>' withdrawal amount',

'tk100'=>' withdrawal amount at least 100 yuan',

'tkmm'=>' withdrawal password',

'tkts' => "if the amount of code printing is insufficient, and your running water has exceeded 8 the recharge amount, please withdraw the cash later, because the player's bet data has not been returned to the cash station, resulting in your running water can not be updated in time. Please understand the inconvenience, or contact the online customer service!",

'dqr'=>' to be confirmed',

'hkcg' =>'success',

'hksb' =>'failed',

'xtgg' =>'Latest News',

'khdz' =>'account opening address',

'xgdlmm' =>'modify login password',

'jmm' =>'old password',

'xmm' =>'new password',

'qrmm' =>'confirm password',

'qr' =>'confirm',

'zfmm' =>'payment password',

'dlmm'=>' login password',

'x6wcsz' =>'6 digits only',

'tglj'=>' promotion link',

'fzlj' =>'copy link',

'ewmtg' =>'QR code promotion',

'yjffjl' =>'commission payment record',

'xxhyckjl' =>'deposit records of offline members',

'xxhytkjl' =>'withdrawal record of offline members',

'xxhy' =>'offline member',

'hysybb' =>'member win / loss',

'kssj' =>'start time',

'jssj' =>'end time',

'yhm' =>'user name',

'chaxun' =>'query',

'ckzs' =>' total deposit',

'ckbs' =>' number of deposits',

'tkze'=>' total withdrawal amount',

'tkbs' =>'number of withdrawals',

'hlze' =>'total bonus',

'hlbs' =>' number of dividends',
  'qddpz'=>'you have unapproved deposits, please wait for approval',
'yl' =>'profit',
'zjls'=>'cash flow',
'hysy' =>'member wins or loses',
'dingdanchaxun'=>'order tracking',
'ckts' =>" you have a deposit that hasn't passed yet, so you can't submit the deposit again ",

'jebxdy' =>'amount must be greater than or equal to',
'jebxxy'=>'amount must be less than or equal to',
'qsrzqdsz' =>'please enter the correct number and keep two decimal places',

'qscjt' =>'please upload the screenshot of successful payment',

'mtzdtk'=>' you can only apply for withdrawal every day at most',

'ci' =>'times',

'dmlbz'=>" you don't have enough code to withdraw ",

'tkjedyye'=>' withdrawal amount is greater than balance',

'qkmmbzq' =>'incorrect withdrawal password',

'tjcg'=>' submitted successfully',

"zggsyh" => "industrial and Commercial Bank of China",

"zgjsyh" => "China Construction Bank",

"zgnyyh" => "Agricultural Bank of China",

"zgyh" => "Bank of China",

"zgjtyh" => "Bank of communications of China",

"zsyh" => "China Merchants Bank",

"gfyh" => "Guangdong Development Bank",

"payh" => "Ping An Bank",

"pfyh" => "Shanghai Pudong Development Bank",

"msyh" => "Minsheng Bank",

"zgyz" => "postal savings bank of China",

"hxyh" => "Huaxia Bank",

"szfz" => "Shenzhen Development Bank",

"zxyh" => "China CITIC Bank",

"xyyh" => "Industrial Bank",

"gdyh" => "Everbright Bank",

"zdyh" => "Standard Chartered Bank",

"hfyh" => "HSBC",

"zxyh" => "ZTE bank",

"hsyh" => "Hang Seng Bank",

"cxyh" => "innovation bank",

"ymmcw" => "original password error",
"zcdl"=>'Agent registration',
'daili'=>'Agent',
'user'=>'Member',







'yswrjqd' =>'british virgin islands',

'bvirz' =>'(bvi) certification',

'jtgfyy' =>'official operation of the group',

'flb' =>'philippines (pagcor)',

'jgbczz' =>'gambling supervision license',

'hdzx' =>'activity center',

'kfzx' =>'customer service',

'edzh' =>'quota conversion',

'grzx' =>'personal center',

'ckwt' =>'deposit problem',

'qkwt' =>'withdraw probl',

'zhwt' =>'account problem',

'yhhd' =>'activity',

'dljm'=>'agent joining',

'yxcg' =>'game venue',

'sxje'=>' refresh amount',

'zjhs' =>' fund recovery',

'zxqb' =>'center wallet',

'yxqb' =>'game wallet',

'qsrzzje' =>'please enter the transfer amount',

'ljzz' =>'transfer immediately',

'xzyx' =>'select game',

'quxiao' =>'cancel',

'jzz' =>'loading',

'hsz' =>'recycling',

'lqmrfl' =>'receive daily benefits',

'byxzze' =>'total bet amount this month',

'fanshui' =>'bonus',

'qbxx' =>'All messages',
'quanbu'=>'All',

'xiaoxi' =>'message',
'czje'=>'deposit amount',
'yy'=>'reason',
'zwjl' =>'no record yet',

'gengduo' =>'more',
'quedingtc'=>'are you sure you want to quit?',
'flhd' =>'welfare activities',

'xiangxi' =>'detailed',
'qikuangmm'=>'enter new password 4-digit withdrawal password',
'qrxmm'=>'confirm new password (4-digit withdrawal password)',
'qrztxxx'=>'please fill in the information carefully',
'xgcg'=>'modified successfully',
'qrxmm620'=>'confirm new password (6-20 regular characters)',
'srxmm620'=>'enter a new password (6-20 regular characters)',
'srjmm'=>'enter the old password',
'baobiao' =>'report',

'cunkuan' =>'deposit',
  'quedihng'=>'sure',
'dqr'=>'to be confirmed',

'chenggong' =>'success',

'shibai'=>' failed',

'zzxm' =>'self code washing, real-time settlement, please try again after the bet meets the standard',

'xnbzf' =>'USDT',

'xfjzf' =>'consumption volume payment',

'skyh'=>' receiving bank',

'hkje' =>'remittance amount',

'qjl' =>'please record the following collection information and remit money',

'fhcxsr' =>'return to re-enter',

'cz1' =>'note: in order to score quickly, please transfer according to the amount prompted by the system,',

'cz2' =>'the transfer amount is accurate to two decimal places. if the amount is not transferred according to the prompt, the system will automatically reject the transfer request',

'cz3' =>'and do not make up points! thank you',

'hqskyhxx' =>'get payee bank information',

'cz4' =>'confirm that the transfer has been made to the specified account, and apply for points',

'czdz' =>'recharge address',

'syml'=>' remaining code quantity',

'zhuti' =>'subject',

'neirong' =>'content',

'fssj'=>'sending time',

'xzrq' =>'select date',

'jinri' =>'today',

'day'=>' day',

'zcgcz' =>'total successful recharge',

'jin' =>'amount',
'sqjd'=>'application progress',
'hgbt'=>'activity title',
'ndhdsqwtg'=>'your event application failed, the reason',
'gongxini'=>'congratulations, your event application has been approved, and the bonus amount has been issued to your account, please check! ',
'ndhdsqzzsh'=>'your event application is under review, please be patient! ',
'zwcjhd'=>'no activity for now',
'yidu'=>'read',
'shijian'=>' time',

'zhuangtai' =>'status',
'querentixian' => 'confirm withdrawal',
'bzzx' =>'help center',
'xxq'=>'relax',
'jieshaoren' => 'introducer',
'p-6-12' => 'please enter 6-12 characters or numbers',
'denglumimaqueren' => 'login password confirmation',
'xuyuyuanmimaxiangtong' => 'must be the same as the original password',
'zhenshixingming' => 'real name',
'zhengquezhenshixingming' => 'Please enter your real English name',
'qingtianxiezhengquedeshoujihao' => 'please fill in the real mobile phone number, one of the ways to retrieve the password',
'tongyizunxuan' => 'agree and be willing to comply',
'yonghuxieyi' => 'user agreement',
'he' => 'and',
'yinsitiaokuan' => 'privacy policy',
'lijizhuce' => 'register now',
'weitongyiyonghuxieyi' => 'i did not agree to the user agreement and terms!',
    'shanglajiazaigengduo' => 'pull up to load more',
    'queshaocanshu' => 'missing necessary parameters',
    'meiyougengduole' => 'no more',
    'jiaoyijine' => 'amount',
    'dingdanhao' => 'order number',
    'jiaoyishijian' => 'trading time',
    'jiaoyifangshi' => 'transaction method',
    'jiaoyizhuangtai' => 'transaction status',
     'beizhu' => 'remarks',
     'jiazaizhong' => 'loading',
     'zongchenggongtixian' => 'total successful withdrawal',
     'fanhui' => 'return',
     'jine' => 'amount',
     'zhlx'=>'account type',
     'dongzuo' => 'action',
     'youximingcheng' => 'game name',
     'shuruzhanghu' => 'transfer account',
     'shuchuzhanghu' => 'out account',
     'tiyu'=>'sport',
     'zhenren'=>'live',
     'qipai'=>'chess',
     'shengyumaliang'=>'remaining code size',
     'caipiao'=>'keno',
     'dianzi'=>'E-game',
          'zhucezhanghu'=>'Register Account',
     'buyu'=>'fishing',
       'zhuce_yiyouzhanghao' => 'have an account',
    'youxizhonglei'=>'game type',
    'zhuce_shouji'=> 'mobile phone number is 8-11 digits',
'zhuce_huoquyanzhema' => 'get code',
'jieshaoren' => 'introducer',
     'p-6-12' => 'please enter 6-12 characters or numbers',
     'denglumimaqueren' => 'login password confirmation',
     'xuyuyuanmimaxiangtong' => 'must be the same as the original password',
     'zhenshixingming' => 'real name',
     'qingtianxiezhengquedeshoujihao' => 'please fill in the real mobile phone number, the king of the way to retrieve the password',
     'tongyizunxuan' => 'agree and be willing to comply',
     'yonghuxieyi' => 'user agreement',
     'qingshuruzanghao'=>'account number (6-9 letters and numbers)',

'qingshurumima'=>'password consists of 6-12 digits or letters',

'qingshuqukuanmima'=>'please enter the withdrawal password 6-10 digits',
'sunyi' => 'profit and loss',
'yijianfanshuijiesuan' => 'One-click rebate settlement',
'kejiesuanjine' => 'The total amount of rebates that can be settled',
'quanbuximajiesuan' => 'All rebate settlement',
'fanshui_alt' => 'Self-rebate, real-time settlement, please bet and try again!',
'leixing' => 'type',
'zongtouzhu' => 'total bet',
'zongfanshu' => 'total rebate',
'shuaxinjine' => 'Refresh amount',
'xiangxizhangkai' => 'Expand in detail',
'lijizhuanzhang' => 'transfer now',
'qingshuruzhuanzhangjine' => 'Please enter the transfer amount',
'bangding_title' => '【Bank card or FPS account, each can only be bound to one group, and must be the same name at the same time】',
'dengchu' => 'Sign out',
'sqdl'=>'Application agent',
'sqly'=>'Reason',
'all'=>'All',
'bkcfsq'=>'Cannot apply repeatedly',
'qczhzl'=>'Please recharge before applying',
'xzyhk'=>'New bank card',
'tips1'=>'Members can only bind one bank card account and one fast transfer account, and the name of the account holder must be the same. If you need to modify it after binding, please contact our 24-hour online customer service.',
'qxcz'=>'Please recharge first',

'yjsql'=>'You have applied for this activity, please apply after recharging tomorrow!',

'hdyjs'=>' The activity has ended, please apply for other activities',

'grxx'=>'Personal information',

'genghuan'=>'Replace',
'ykh'=>'Bank',



    'png'=>'/new0404/images/i_flag_en.png',
'yuyan'=>'Language',
'yebz' =>'insufficient account balance',

'zzwh' =>'being maintained',

'sbcw'=>' failed! Error',

'lxkf' =>'please contact customer service for solution',
    
   'xgzfmm'=>'payment password',
   'wmztj'=>'Conditions not met',
   'liushui'=>'Water',
   'yjlq'=>'Collection',
   'khje'=>'Exchangeable amount',
   'fsts'=>'Because the game data return time of the interface party is not fixed, the real-time backwater amount is inaccurate. It is recommended that you receive the real-time backwater one hour after stopping the game!',
   'qsr'=>'Please enter',
    
  'lang' =>'En',

'lang_logo'=>'/data/en_us.png',

'zanghao' =>'account number',

'mima'=>' password',

'denglu'=>' Login',

'qingshuru' =>'please enter',

'qingzaicishuru' =>'please enter again',

'qkmm' =>'withdrawal password',

'wjmm' =>'forgot password',

'ljzc' =>'register now',

'zhbjy' =>'the account is disabled',

'yhmmcw' =>'wrong user name or password',

'qsryqm' =>'please enter the introducer',

'lxkf' =>'contact customer service',

'xzapp' =>'existing account, Download app',

'weixin' =>'wechat',

'zxkf' =>'online customer service',

'zxrs' =>' number of people online',

'hyn' =>'welcome',

'zhuce' =>'register',

'chongzhi' =>'recharge',

'edu' =>'quota',

'tikuan'=>' withdrawal',

'dianzi'=>' electronic',

'shixun'=>' video',

'caipiao' =>'lottery',

'tiyu'=>' Sports',

'dianjing'=>' ESports',

'qipai' =>'chess',

'buyu' =>'fishing',

'shouye'=>' home',

'yhhd' =>'preferential activities',

'edzh' =>'quota conversion',

'tzjl'=>' betting record',

'wode' =>'mine',

'hdzx' =>'activity center',

'hdxq' =>'activity details',

'yehz' =>'balance transfer',

'zhye' =>'account balance',

'qxzpt' =>'please select a platform',

'zhuanru' =>'transfer in',

'zhuanchu' =>'transfer out',

'tijiao'=>' submit',

'yxlb' =>'game list',

'wkt' =>'not opened',

'yjzr' =>'all in',

'yjzc' =>'all out',

'sxcg'=>' refresh succeeded',

'srje'=>' enter amount',

'yxjl' =>'game record',

'yxxz' =>'valid bet',

'yuan' =>'$',

'wanfa' =>'play method',

'touzhu'=>' betting',

'zjj' =>'prize money',

'zzhye' =>'master account balance',

'jrtz' =>'bet today',

'jryk' =>'profit and loss today',

'zhuan' =>'transfer',

'ssfs' =>'real time water return',

'fsjl' =>'water return record',

'czjl' =>'recharge record',

'txjl'=>' withdrawal record',

'edzhjl' =>'quota conversion record',

'dlzx'=>' agent center',

'xxzx' =>'message center',

'xgmm' =>'modify password',

'tcdl'=>' exit Login',


'qxzczfs' =>' select recharge method',

'bldzz' =>'value added convenience store',

'hdsj' =>'activity time: long term effective',

'msrkh'=>' no need to input card number, convenient and fast',

'zfbsm'=>'Alipay scan code recharge',

'zsk' =>'fast revolutions',

'czje' =>'recharge amount',

'skewm'=>' collection QR code',

'fkjt' =>'payment screenshot',

'zftx' =>'the payment must be paid in full Yuan and jiao (the minimum payment amount is 100 yuan)',

'qrcz' =>'confirm recharge',

'zdyz' =>'only 1 picture can be selected at most',

'Xingming' =>'name',

'qsrfkrxm' => "please enter the payer's name",

'zfbts1' =>'1. Please fill in the remittance information form at the bottom of this page after the amount is transferred out, so that the financial system can confirm and add the amount to your member account in time.',

'zfbts2' =>'2. The minimum deposit amount of the company is 100 yuan, and the financial system of the company will distribute rebates to members with bank deposits according to the actual deposit amount.',

'zfbts3' =>'3. For inter-bank transfer, please use inter-bank express remittance.',

'skzh'=>' collection account',

'skzhm'=>' collection account name',

'fuzhi' =>'copy',

'fzcg' =>'copy succeeded',

'tixian'=>' withdrawal',

'txfs' =>'withdrawal method',

'qxz' =>'please select',

'mlye'=>' code quantity balance',

'skzh'=>' collection account number',

'tkje'=>' withdrawal amount',

'tk100'=>' withdrawal amount at least 100 yuan',

'tkmm'=>' withdrawal password',

'tkts' => "if the amount of code printing is insufficient, and your running water has exceeded 8 the recharge amount, please withdraw the cash later, because the player's bet data has not been returned to the cash station, resulting in your running water can not be updated in time. Please understand the inconvenience, or contact the online customer service!",

'dqr'=>' to be confirmed',

'hkcg' =>'remittance succeeded',

'hksb' =>'remittance failed',

'xtgg' =>'system announcement',

'khdz' =>'account opening address',

'xgdlmm' =>'modify login password',

'jmm' =>'old password',

'xmm' =>'new password',

'qrmm' =>'confirm password',

'qr' =>'confirm',

'zfmm' =>'payment password',

'dlmm'=>' login password',

'x6wcsz' =>'6 digits only',

'tglj'=>' promotion link',

'fzlj' =>'copy link',

'ewmtg' =>'QR code promotion',

'yjffjl' =>'commission payment record',

'xxhyckjl' =>'deposit records of offline members',

'xxhytkjl' =>'withdrawal record of offline members',

'xxhy' =>'offline member',

'hysybb' =>'member win / loss',

'kssj' =>'start time',

'jssj' =>'end time',

'yhm' =>'user name',

'chaxun' =>'query',

'ckzs' =>' total deposit',

'ckbs' =>' number of deposits',

'tkze'=>' total withdrawal amount',

'tkbs' =>'number of withdrawals',

'hlze' =>'total bonus',

'hlbs' =>' number of dividends',

'yl' =>'profit',

'hysy' =>'member wins or loses',

'ckts' =>" you have a deposit that hasn't passed yet, so you can't submit the deposit again ",

'jebxdy' =>'amount must be greater than or equal to',

'qsrzqdsz' =>'please enter the correct number and keep two decimal places',

'qscjt' =>'please upload the screenshot of successful payment',

'mtzdtk'=>' you can only apply for withdrawal every day at most',

'ci' =>'times',

'dmlbz'=>" you don't have enough code to withdraw ",

'tkjedyye'=>' withdrawal amount is greater than balance',

'qkmmbzq' =>'incorrect withdrawal password',

'tjcg'=>' submitted successfully',

"zggsyh" => "industrial and Commercial Bank of China",

"zgjsyh" => "China Construction Bank",

"zgnyyh" => "Agricultural Bank of China",

"zgyh" => "Bank of China",

"zgjtyh" => "Bank of communications of China",

"zsyh" => "China Merchants Bank",

"gfyh" => "Guangdong Development Bank",

"payh" => "Ping An Bank",

"pfyh" => "Shanghai Pudong Development Bank",

"msyh" => "Minsheng Bank",

"zgyz" => "postal savings bank of China",

"hxyh" => "Huaxia Bank",

"szfz" => "Shenzhen Development Bank",

"zxyh" => "China CITIC Bank",

"xyyh" => "Industrial Bank",

"gdyh" => "Everbright Bank",

"zdyh" => "Standard Chartered Bank",

"hfyh" => "HSBC",

"zxyh" => "ZTE bank",

"hsyh" => "Hang Seng Bank",

"cxyh" => "innovation bank",

"ymmcw" => "original password error",
"zcdl"=>'Agent registration',
'daili'=>'Agent',
'user'=>'Member',







'yswrjqd' =>'british virgin islands',

'bvirz' =>'(bvi) certification',

'jtgfyy' =>'official operation of the group',

'flb' =>'philippines (pagcor)',

'jgbczz' =>'gambling supervision license',

'hdzx' =>'activity center',

'kfzx' =>'customer service',

'edzh' =>'quota conversion',

'grzx' =>'personal center',

'ckwt' =>'deposit problem',

'qkwt' =>'withdraw probl',

'zhwt' =>'account problem',

'yhhd' =>'activity',

'dljm'=>'agent joining',

'yxcg' =>'game venue',

'sxje'=>' refresh amount',

'zjhs' =>' fund recovery',

'zxqb' =>'center wallet',

'yxqb' =>'game wallet',

'qsrzzje' =>'please enter the transfer amount',

'ljzz' =>'transfer immediately',

'xzyx' =>'select game',

'quxiao' =>'cancel',

'jzz' =>'loading',

'hsz' =>'recycling',

'lqmrfl' =>'receive daily benefits',

'byxzze' =>'total bet amount this month',

'fanshui' =>'bonus',

'qbxx' =>'all messages',

'xiaoxi' =>'message',

'zwjl' =>'no record yet',

'gengduo' =>'more',

'flhd' =>'welfare activities',

'xiangxi' =>'detailed',

'baobiao' =>'report',

'cunkuan' =>'deposit',

'dqr'=>'to be confirmed',

'chenggong' =>'success',

'shibai'=>' failed',

'zzxm' =>'self code washing, real-time settlement, please try again after the bet meets the standard',

'xnbzf' =>'virtual currency payment',

'xfjzf' =>'consumption volume payment',

'skyh'=>' receiving bank',

'hkje' =>'remittance amount',

'qjl' =>'please record the following collection information and remit money',

'fhcxsr' =>'return to re-enter',

'cz1' =>'note: in order to score quickly, please transfer according to the amount prompted by the system,',

'cz2' =>'the transfer amount is accurate to two decimal places. if the amount is not transferred according to the prompt, the system will automatically reject the transfer request',

'cz3' =>'and do not make up points! thank you',

'hqskyhxx' =>'get payee bank information',

'cz4' =>'confirm that the transfer has been made to the specified account, and apply for points',

'czdz' =>'recharge address',

'syml'=>' remaining code quantity',

'zhuti' =>'subject',

'neirong' =>'content',

'fssj'=>'sending time',

'xzrq' =>'select date',

'jinri' =>'today',

'day'=>' day',

'zcgcz' =>'total successful recharge',

'jin' =>'amount',

'shijian'=>' time',

'zhuangtai' =>'status',

'bzzx' =>'help center',
'xxq'=>'relax',
'shengyujihe'=>'Remaining amount',
    'xiangxilianxikefu'=>'Please contact customer service for details'
];
    