<div class="container-fluid" style="margin-bottom: 10px;">
    <form action="" method="get" id="searchForm">
        <div class="row">

            <div class="col-lg-2 pull-right">
                <div class="input-group">
                    <!--<button type="submit" class="btn btn-primary">搜索</button>&nbsp;&nbsp;-->
                    <a class="btn btn-info" href="{{ route('red.create') }}"><span class="glyphicon glyphicon-plus"></span>添加奖品</a>
                    <a class="btn btn-info" href="{{ route('admin.giveindex') }}"><span class="glyphicon glyphicon-plus"></span>赠送次数</a>
                </div>
            </div>
        </div>
    </form>
</div>