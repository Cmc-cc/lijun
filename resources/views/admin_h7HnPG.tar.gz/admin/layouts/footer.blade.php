<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
         梦想远航
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2019 <a href="#"></a>.</strong> All rights reserved.
</footer>
