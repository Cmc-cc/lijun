<!doctype html>
<html class="s-app" data-n-head-ssr lang="zh-TW" data-n-head="%7B%22lang%22:%7B%22ssr%22:%22zh-TW%22%7D%7D">
<head>
    <title>{{ $_system_config->site_title}}</title>
    <meta data-n-head="ssr" charset="utf-8">
    <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1">
    <meta data-n-head="ssr" data-hid="og:url" property="og:url" content="https://q8.bet">
    <meta data-n-head="ssr" data-hid="keywords" name="keywords"
          content="娛樂城體育,娛樂城優惠,線上娛樂城,娛樂城註冊優惠,現金版推薦,現金球版推薦,大發網現金版,WG CLUB娛樂城,歐博,沙龍,dg,super,新鑫寶,真人視訊,百家樂,骰寶,賓果,21點,體育賽事,免費影城,老虎機,樂透,北京賽車,手中寶,任你贏彩票,美女主播, av女優、世界盃,棒球12強賽事">
    <meta data-n-head="ssr" data-hid="og:title" property="og:title"
          content="WG CLUB娛樂城│業界誠信高,多款遊戲線上遊戲平台│體育博彩│真人視訊│百家樂│骰寶│六合彩│老虎機">
    <meta data-n-head="ssr" data-hid="og:description" property="og:description"
          content="WG CLUB爲亞洲最大在線合法網上博弈娛樂平台。安全便利, 信譽最佳保證出金，WG CLUB提供各種最新真人視訊百家樂、電子遊戲、SLOT-game、線上六合彩、高賠率運動賽事等賽事遊戲無限，體育直播以及24小時線上客服。">
    <meta data-n-head="ssr" data-hid="charset" charset="utf-8">
    <meta data-n-head="ssr" data-hid="mobile-web-app-capable" name="mobile-web-app-capable" content="yes">
    <meta data-n-head="ssr" data-hid="apple-mobile-web-app-capable" name="apple-mobile-web-app-capable" content="yes">
    <meta data-n-head="ssr" data-hid="apple-mobile-web-app-status-bar-style"
          name="apple-mobile-web-app-status-bar-style" content="default">
    <meta data-n-head="ssr" data-hid="apple-mobile-web-app-title" name="apple-mobile-web-app-title" content="WG CLUB娛樂城">
    <meta data-n-head="ssr" data-hid="description" name="description"
          content="WG CLUB爲亞洲最大在線合法網上博弈娛樂平台。安全便利, 信譽最佳保證出金，WG CLUB提供各種最新真人視訊百家樂、電子遊戲、SLOT-game、線上六合彩、高賠率運動賽事等賽事遊戲無限，體育直播以及24小時線上客服。">
    <meta data-n-head="ssr" data-hid="theme-color" name="theme-color" content="#000000">
    <meta data-n-head="ssr" data-hid="og:type" name="og:type" property="og:type" content="website">
    <meta data-n-head="ssr" data-hid="og:site_name" name="og:site_name" property="og:site_name" content="WG CLUB娛樂城">
        <style>
        .top_nav h5 img {
            margin-top: 10px;
        }
    </style>
</head>
<body class="s-app">
<div data-server-rendered="true" id="__nuxt"><!---->
    <div id="__layout">
        <div data-fetch-key="0">
            <div data-app="true" id="app" class="v-application v-application--is-ltr theme--dark">
                <div class="v-application--wrap">
                   @include('web.layouts.header_q8')
                    <main class="v-main"
                          style="padding-right:0px;padding-bottom:0px;padding-left:0px;">
                        <div class="v-main__wrap">
                            <div role="dialog" class="v-dialog__container UiAnnouncement"><!----></div>
                            <div data-fetch-key="1" id="announcement" class="container"><!---->
                                <div class="mx-auto v-sheet theme--dark transparent" style="max-width:1280px;">
                                    <div class="d-flex justify-center align-center pa-4"><h2>{{trans("lang.xtgg")}}</h2></div>
                                    <hr role="separator" aria-orientation="horizontal" class="v-divider theme--dark">
                                    <div class="row">
                                        <!--<div class="col-lg-3 col-12">
                                            <div id="UiFilterLists" class="filter v-card v-sheet theme--dark">
                                                <div role="list"
                                                     class="v-list v-sheet theme--dark v-list--dense v-list--nav">
                                                    <div role="listbox"
                                                         class="v-item-group theme--dark v-list-item-group primary--text">
                                                        <div tabindex="0" role="listitem" aria-selected="true"
                                                             class="v-list-item v-item--active v-list-item--active v-list-item--link theme--dark">
                                                            <div class="v-list-item__content">全部</div>
                                                        </div>
                                                        <div tabindex="0" role="listitem" aria-selected="false"
                                                             class="v-list-item v-list-item--link theme--dark">
                                                            <div class="v-list-item__content">系統公告</div>
                                                        </div>
                                                        <div tabindex="0" role="listitem" aria-selected="false"
                                                             class="v-list-item v-list-item--link theme--dark">
                                                            <div class="v-list-item__content">會員福利</div>
                                                        </div>
                                                        <div tabindex="0" role="listitem" aria-selected="false"
                                                             class="v-list-item v-list-item--link theme--dark">
                                                            <div class="v-list-item__content">會員權益</div>
                                                        </div>
                                                        <div tabindex="0" role="listitem" aria-selected="false"
                                                             class="v-list-item v-list-item--link theme--dark">
                                                            <div class="v-list-item__content">維護公告</div>
                                                        </div>
                                                    </div>
                                                    </div>
                                            </div>
                                        </div>-->
                                        <div class="card-item-list col-lg-12 col-12">
                                           @foreach($_system_notices as $v)
                                            <div width="100%"  onclick="showDetails('{{$v->content}}','{{$v->title}}');">
                                                <div class="mb-5">
                                                    <div tabindex="0" class="v-card v-card--link v-sheet theme--dark">
                                                        <div class="v-image v-responsive theme--dark">
                                                            <div class="v-responsive__content" style="display:none;">{{ $v->title }}</div>
                                                        </div>
                                                        <div class="v-card__title">{{ $v->content }}
                                                        </div>
                                                        <div class="v-card__subtitle text-right">{{ $v->created_at }}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                               @endforeach
                                           
                                            
                                      
                                            <!--<nav role="navigation" aria-label="分頁導航">
                                                <ul class="v-pagination theme--dark">
                                                    <li>
                                                        <button type="button" aria-label="上一頁"
                                                                class="v-pagination__navigation v-pagination__navigation--disabled">
                                                            <i aria-hidden="true"
                                                               class="v-icon notranslate mdi mdi-chevron-left theme--dark"></i>
                                                        </button>
                                                    </li>
                                                    <li>
                                                        <button type="button" aria-current="true" aria-label="當前頁 1"
                                                                class="v-pagination__item v-pagination__item--active primary">
                                                            1
                                                        </button>
                                                    </li>
                                                    <li>
                                                        <button type="button" aria-label="轉到頁面 2"
                                                                class="v-pagination__item">2
                                                        </button>
                                                    </li>
                                                    <li>
                                                        <button type="button" aria-label="下一頁"
                                                                class="v-pagination__navigation"><i aria-hidden="true"
                                                                                                    class="v-icon notranslate mdi mdi-chevron-right theme--dark"></i>
                                                        </button>
                                                    </li>
                                                </ul>
                                            </nav>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                                        
                    <div role="document" id="notice_" tabindex="0" class="v-dialog__content v-dialog__content--active" style="z-index: 202;display:none;">
                        <div class="v-dialog v-dialog--active v-dialog--scrollable" style="transform-origin: center center; max-width: 600px;">
                            <div class="v-card v-sheet theme--dark">
                                <div class="v-card__title">
                                    <button type="button" onclick="hideTc();" class="v-btn v-btn--absolute v-btn--fab v-btn--flat v-btn--icon v-btn--right v-btn--round theme--dark v-size--default primary--text">
                                        <span class="v-btn__content"><i aria-hidden="true" class="v-icon notranslate mdi mdi-close theme--dark"></i></span>
                                    </button> 
                                    <div>
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">{{trans("lang.xtgg")}}</font>
                                        </font>
                                    </div>
                                </div>
                                <div class="v-card__title">
                                    <font style="vertical-align: inherit;">
                                        <font style="vertical-align: inherit;" id="notice_title"></font>
                                    </font>
                                </div> 
                                <div class="v-card__text v-html" style="height: 30vh;">
                                    <p>
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;" id="notice_content"></font>
                                        </font>
                                        <br>
                                    </p>
                                </div> 
                        </div>
                    </div>
                </div>


                        </div>
                    </main>
                    @include('web.layouts.footer_q8')
                </div>
            </div>
        </div>
    </div>
</div>
<script src="/new0404/js/jquery.min.js"></script>
<script>
       function showDetails(content,title){
            $("#notice_").show();
            $("#notice_content").html(content);
           // $("#notice_title").html(title);
        }
    function hideTc(){
        $("#notice_").hide();
    }
</script>

</body>
</html>
