<html class=" js cssgradients generatedcontent" style="" language="tw"><!--<![endif]-->
<head>
    <meta charset="UTF-8">
    <title>{{ $_system_config->site_title  or 'motoo' }}</title>
    <script src="/new0404/pc/js/jquery-1.12.4.js"></script>
    <script src="/new0404/pc/js/jquery-ui.js"></script>
    <script src="/new0404/pc/js/modernizr.custom.js"></script>
    <script src="/new0404/pc/js/velocity.min.js"></script>
    <script src="/new0404/pc/js/ImgPreload.js"></script>
    <script src="/new0404/pc/js/parallax.min.js"></script>
    <script src="/new0404/pc/js/script.js"></script>
    <link href="/new0404/pc/css/normalize.css?202205020105" rel="stylesheet">
    <link href="/new0404/pc/css/main.css?202205020105" rel="stylesheet">
    <link href="/new0404/pc/css/sports2.css?202205020105" rel="stylesheet">
    <link href="/new0404/pc/css/loading.css?202205020105" rel="stylesheet">
    <link href="/new0404/pc/css/main-1440.css?202205020105" rel="stylesheet"
          media="screen and (max-width:1600px)">
    <link rel="stylesheet" href="/new0404/pc/css/language_tw.css" id="languageCss">
</head>
<body>
<style>
    .asas:hover{
        background:url(/new0404/pc/images/OBSPORT01.png);
    }
</style>
<div class="container">
    <div class="top-box">
    @include('member.layouts.pc_header')
    <!-- main -->
        <div class="main_wrap">
            <div class="loadingTracker">
                <div class="loadingSymbol">
                    <div class="logo2"></div>
                </div>
            </div>
            <div class="content" style="">
                <div class="sports-site">
                   <!--<div class="sport-playbtnCMD toplay" groupid="45" onclick="alert('遊戲維護中')" data-code="TFG" style="left: 970px;top: 93px;">-->
                   <!--     <a groupid="45" class="openGame" gamename="TFG" gametype="0" oncontextmenu="return false;"></a>-->
                   <!-- </div>-->
                    <div class="sport-playbtn2 toplay" groupid="25" @if($_member) data-url="/game/playGame?plat_type=IA&game_type=5&game_code=&devices=1" @else data-url="" @endif data-code="IA">
                        <a groupid="25" class="openGame" gamename="IA" gametype="0"  oncontextmenu="return false;"></a>
                    </div>
                    <div class="sport-playbtnOBSPORT toplay asas" groupid="138" @if($_member) data-url="/game/playGame?plat_type=OB&game_type=5&game_code=&devices=1" @else data-url="" @endif data-code="OB">
                        <a groupid="138" class="openGame" gamename="OBSPORT" gametype="0" target="_blank"
                           oncontextmenu="return false;"></a>
                    </div>
                    <div class="sport-playbtnBBIN toplay asas" groupid="4" @if($_member) data-url="/game/playGame?plat_type=ST_HK&game_type=5&game_code=&devices=1" @else data-url="" @endif data-code="ST_HK">
                        <a groupid="4" class="openGame" gamename="ST_HK" gametype="FT"  oncontextmenu="return false;"></a>
                    </div>
                 <div class="sport-playbtn toplay asas" groupid="91" @if($_member) data-url="/game/playGame?plat_type=CM_HK&game_type=5&game_code=&devices=1" @else data-url="" @endif data-code="CM_HK" style="top: 35px;">
                         <a groupid="91" class="openGame" gamename="CM_HK" gametype="0"  oncontextmenu="return false;"></a> 
                    </div>
                    <div class="sport-playbtnCRSPORT toplay" @if($_member) data-url="/game/playGame?plat_type=SO_HK&game_type=5&game_code=&devices=1" @else data-url="" @endif data-code="SO_HK" style="top: 35px;">
                            <a groupid="214" class="openGame" gamename="SO_HK" gametype="0" target="_blank" oncontextmenu="return false;"></a>
                    </div>
                        
                        
                    <!--<div class="sport-playbtnm8 toplay" groupid="36" @if($_member) data-url="/game/playGame?plat_type=TFG&game_type=1&game_code=&devices=1" @else data-url="" @endif data-code="TFG">-->
                    <!--    <a groupid="36" class="openGame" gamename="M8" gametype="0" oncontextmenu="return false;"></a>-->
                    <!--</div>-->
                    
                    
                    
                    
                    
                    
                    
                    
                </div>
            </div>
        </div>
        @include('member.layouts.pc_footer')
    </div>
</div>
@include('member.layouts.pc_right')
</body>
</html>