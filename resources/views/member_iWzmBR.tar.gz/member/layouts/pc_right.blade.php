<div class="footer">
    <div class="copyright" id="bottomtitle"></div>
    <a href="#" class="btn btn-gotop"><i class="icon icon-gotop"></i></a>
</div>
<div class="fix_layout">
    <div class="fl_in">
        <div class="service_tool">
            <ul>
                <!--<li class="test_button"><a class="aftertext_7" id="freeplay" title="freeplay"
                                           oncontextmenu="return false;"></a></li>-->
                <li><a class="aftertext_1" data-toggle="cs" href="{{ $_system_config->service_link }}" target="_blank"
                       onclick="javascript:openChat('{{ $_system_config->service_link }}','900','600');" '=""
                    oncontextmenu="return false;"></a></li>
               <!--<li><a class="aftertext_3" href="/r" oncontextmenu="return false;"></a></li>-->
                <li class="appdownload-box" style="display: list-item;"><a class="QRCodeBtn aftertext_6" goal="W3"
                                                                           oncontextmenu="return false;"></a>
                    <div id="W3" class="hover-box"><img
                                src="https://www.123.com/new/img/25113113331.png">
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>