<div class="container-fluid" style="margin-bottom: 10px;">
    <form action="" method="get" id="searchForm">
        <div class="row">
            <div class="col-lg-2 pull-right">
                <div class="input-group">
                    <a class="btn btn-info" href="{{ route('advpos.create') }}"><span class="glyphicon glyphicon-plus"></span>添加焦点图</a>
                </div>
            </div>
        </div>
    </form>
</div>